import React, { useState } from 'react';
import { Question } from '../types';
import { CheckCircle as CircleCheck, Circle as CircleX } from 'lucide-react';

interface QuizProps {
  questions: Question[];
  onComplete: (score: number) => void;
}

export function Quiz({ questions, onComplete }: QuizProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);

  const handleAnswer = (answer: string) => {
    if (isAnswered) return;
    
    setSelectedAnswer(answer);
    setIsAnswered(true);
    
    if (answer === questions[currentQuestion].correctAnswer) {
      setScore(score + 1);
    }

    setTimeout(() => {
      if (currentQuestion === questions.length - 1) {
        onComplete(score);
      } else {
        setCurrentQuestion(currentQuestion + 1);
        setSelectedAnswer(null);
        setIsAnswered(false);
      }
    }, 1000);
  };

  const question = questions[currentQuestion];

  return (
    <div className="w-full max-w-2xl">
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <span className="text-sm font-medium text-gray-500">
            Question {currentQuestion + 1}/{questions.length}
          </span>
          <span className="text-sm font-medium text-gray-500">
            Score: {score}
          </span>
        </div>
        <h2 className="text-xl font-semibold text-gray-800 mb-6">{question.question}</h2>
        <div className="space-y-3">
          {question.options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleAnswer(option)}
              disabled={isAnswered}
              className={`w-full p-4 text-left rounded-lg transition-all ${
                isAnswered
                  ? option === question.correctAnswer
                    ? 'bg-green-100 border-green-500'
                    : option === selectedAnswer
                    ? 'bg-red-100 border-red-500'
                    : 'bg-white border-gray-200'
                  : 'bg-white hover:bg-gray-50 border-gray-200'
              } border-2`}
            >
              <div className="flex items-center justify-between">
                <span>{option}</span>
                {isAnswered && option === question.correctAnswer && (
                  <CircleCheck className="text-green-500" />
                )}
                {isAnswered && option === selectedAnswer && option !== question.correctAnswer && (
                  <CircleX className="text-red-500" />
                )}
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}