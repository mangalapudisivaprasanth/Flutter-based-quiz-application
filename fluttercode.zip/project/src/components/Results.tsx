import React from 'react';
import { Trophy } from 'lucide-react';

interface ResultsProps {
  score: number;
  totalQuestions: number;
  onRestart: () => void;
}

export function Results({ score, totalQuestions, onRestart }: ResultsProps) {
  const percentage = (score / totalQuestions) * 100;

  return (
    <div className="text-center">
      <div className="mb-8">
        <Trophy className="w-16 h-16 mx-auto text-yellow-500 mb-4" />
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Quiz Completed!</h2>
        <p className="text-gray-600">
          You scored {score} out of {totalQuestions} questions correctly
        </p>
        <div className="mt-4">
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div
              className="bg-blue-600 h-2.5 rounded-full"
              style={{ width: `${percentage}%` }}
            ></div>
          </div>
          <p className="mt-2 text-sm text-gray-500">{Math.round(percentage)}% Accuracy</p>
        </div>
      </div>
      <button
        onClick={onRestart}
        className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
      >
        Try Again
      </button>
    </div>
  );
}