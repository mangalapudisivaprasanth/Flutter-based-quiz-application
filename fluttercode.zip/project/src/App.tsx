import React, { useState, useEffect } from 'react';
import { Brain } from 'lucide-react';
import { Quiz } from './components/Quiz';
import { Results } from './components/Results';
import { fetchQuizData } from './api';
import type { QuizData } from './types';

function App() {
  const [quizData, setQuizData] = useState<QuizData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [quizStarted, setQuizStarted] = useState(false);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [finalScore, setFinalScore] = useState(0);

  useEffect(() => {
    loadQuizData();
  }, []);

  async function loadQuizData() {
    try {
      const data = await fetchQuizData();
      setQuizData(data);
    } catch (err) {
      setError('Failed to load quiz data. Please try again later.');
    } finally {
      setIsLoading(false);
    }
  }

  const handleStartQuiz = () => {
    setQuizStarted(true);
  };

  const handleQuizComplete = (score: number) => {
    setFinalScore(score);
    setQuizCompleted(true);
  };

  const handleRestart = () => {
    setQuizStarted(false);
    setQuizCompleted(false);
    setFinalScore(0);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading quiz...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center text-red-600">
          <p>{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-lg p-8 max-w-2xl w-full">
        {!quizStarted ? (
          <div className="text-center">
            <Brain className="w-16 h-16 mx-auto text-blue-600 mb-6" />
            <h1 className="text-3xl font-bold text-gray-800 mb-4">Welcome to the Quiz!</h1>
            <p className="text-gray-600 mb-8">
              Test your knowledge with our interactive quiz. Ready to begin?
            </p>
            <button
              onClick={handleStartQuiz}
              className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Start Quiz
            </button>
          </div>
        ) : quizCompleted ? (
          <Results
            score={finalScore}
            totalQuestions={quizData?.questions.length || 0}
            onRestart={handleRestart}
          />
        ) : (
          quizData && (
            <Quiz
              questions={quizData.questions}
              onComplete={handleQuizComplete}
            />
          )
        )}
      </div>
    </div>
  );
}

export default App;